import { supabase } from "./supabase"

export async function ensureUserBucket(userId: string): Promise<boolean> {
  const bucketName = `user-${userId}`
  let retries = 3
  let delay = 1000

  while (retries > 0) {
    try {
      // Check if bucket exists
      const { data: buckets, error: listError } = await supabase.storage.listBuckets()

      if (listError) throw listError

      const bucketExists = buckets?.some((b) => b.name === bucketName)

      if (!bucketExists) {
        console.log("Creating bucket:", bucketName)
        // Updated bucket creation code using the correct API syntax
        const { data, error: createError } = await supabase.storage.createBucket(bucketName, {
          public: false,
          fileSizeLimit: 52428800, // 50MB
          allowedMimeTypes: [
            "application/pdf",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          ],
        })

        if (createError) throw createError

        // Create a policy to allow authenticated users to upload files to their own bucket
        const { error: policyError } = await supabase.storage.from(bucketName).createSignedUploadUrl("test.txt")
        if (policyError) {
          console.warn("Policy creation warning:", policyError)
        }

        // Wait for bucket to be ready
        await new Promise((resolve) => setTimeout(resolve, 1000))
      }

      // Verify bucket is accessible
      const { error: verifyError } = await supabase.storage.from(bucketName).list()
      if (verifyError) throw verifyError

      return true
    } catch (error) {
      console.error(`Bucket creation attempt ${4 - retries} failed:`, error)
      retries--

      if (retries === 0) {
        throw new Error("Failed to ensure bucket exists")
      }

      await new Promise((resolve) => setTimeout(resolve, delay))
      delay *= 2
    }
  }

  return false
}

export async function uploadFile(userId: string, file: File, overwrite = false) {
  const bucketName = `user-${userId}`

  // Ensure bucket exists before upload
  await ensureUserBucket(userId)

  // Clean the filename but keep the original name without timestamp
  const fileExt = file.name.split(".").pop()?.toLowerCase() || ""
  const cleanFileName = file.name
    .split(".")
    .slice(0, -1)
    .join(".")
    .replace(/[^a-z0-9]/gi, "-")
    .toLowerCase()
  const fileName = `${cleanFileName}.${fileExt}`

  // Upload file
  const { error: uploadError } = await supabase.storage.from(bucketName).upload(fileName, file, {
    cacheControl: "3600",
    upsert: overwrite, // Use the overwrite parameter to determine upsert behavior
  })

  if (uploadError) throw uploadError

  // Get signed URL
  const { data: urlData } = await supabase.storage.from(bucketName).createSignedUrl(fileName, 60 * 60 * 24) // 24 hours expiry

  if (!urlData?.signedUrl) {
    throw new Error("Failed to get signed URL")
  }

  return {
    url: urlData.signedUrl,
    fileName,
  }
}

export async function deleteFile(userId: string, fileName: string) {
  const bucketName = `user-${userId}`

  try {
    // First, check if the file exists
    const { data: files, error: listError } = await supabase.storage.from(bucketName).list()

    if (listError) throw listError

    const fileExists = files?.some((file) => file.name === fileName)
    if (!fileExists) {
      throw new Error("File not found")
    }

    // Delete the file
    const { error: deleteError } = await supabase.storage.from(bucketName).remove([fileName])

    if (deleteError) throw deleteError

    return true
  } catch (error) {
    console.error("Error deleting file:", error)
    throw error
  }
}

export async function listFiles(userId: string) {
  const bucketName = `user-${userId}`

  // Check if bucket exists first
  const { data: buckets } = await supabase.storage.listBuckets()
  const bucketExists = buckets?.some((b) => b.name === bucketName)

  if (!bucketExists) {
    return []
  }

  const { data, error } = await supabase.storage.from(bucketName).list()

  if (error) throw error

  return data || []
}

