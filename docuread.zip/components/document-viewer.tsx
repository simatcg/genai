"use client"

import { useState, memo } from "react"
import DocViewer, { DocViewerRenderers } from "@cyntler/react-doc-viewer"
import { FileText } from "lucide-react"

interface DocumentViewerProps {
  file: File | null
  url?: string
}

function DocumentViewer({ file, url }: DocumentViewerProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Create documents array for the viewer
  const docs = []
  if (file) {
    docs.push({
      uri: URL.createObjectURL(file),
      fileName: file.name,
    })
  } else if (url) {
    docs.push({
      uri: url,
      fileName: url.split("/").pop() || "document",
    })
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-red-500">
        <FileText className="h-12 w-12 mb-4" />
        <p className="text-lg font-medium">Error loading document</p>
        <p className="text-sm">{error}</p>
      </div>
    )
  }

  if (!file && !url) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-slate-500">
        <FileText className="h-12 w-12 mb-4" />
        <p className="text-lg font-medium">No document loaded</p>
        <p className="text-sm">Upload a document to view its contents</p>
      </div>
    )
  }

  return (
    <div className="h-full w-full bg-white relative">
      {/* Custom scrollbar container */}
      <div className="absolute inset-0 overflow-auto custom-scrollbar">
        <DocViewer
          documents={docs}
          renderers={DocViewerRenderers}
          style={{
            width: "100%",
            height: "100%",
            backgroundColor: "white",
          }}
          config={{
            header: {
              disableHeader: true,
              disableFileName: true,
            },
            pdfZoom: {
              defaultZoom: 1,
              zoomJump: 0.2,
            },
            pdfVerticalScrollByDefault: true,
          }}
          pluginRenderers={DocViewerRenderers}
          theme={{
            primary: "#2563eb",
            secondary: "#f1f5f9",
            tertiary: "#e2e8f0",
            text_primary: "#020617",
            text_secondary: "#64748b",
            text_tertiary: "#94a3b8",
            disableTheme: true,
          }}
        />
      </div>
    </div>
  )
}

// Export a memoized version of the component
export default memo(DocumentViewer)

// Also export the non-memoized version for flexibility
export { DocumentViewer }

