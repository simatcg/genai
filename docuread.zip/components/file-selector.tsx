"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { listFiles } from "@/lib/storage"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { FileIcon, Loader2, Eye, LogIn } from "lucide-react"
import { supabase } from "@/lib/supabase"

interface FileInfo {
  name: string
  created_at: string
  size: number
  id: string
  metadata: {
    size: number
    mimetype: string
  }
}

interface FileSelectorProps {
  onFileSelect: (fileName: string, url: string, isExistingFile: boolean) => void
  refreshTrigger?: number
}

export function FileSelector({ onFileSelect, refreshTrigger = 0 }: FileSelectorProps) {
  const [files, setFiles] = useState<FileInfo[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [viewingFile, setViewingFile] = useState<string | null>(null)
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      fetchFiles()
    } else {
      // If no user, set loading to false
      setIsLoading(false)
    }
  }, [user, refreshTrigger])

  const fetchFiles = async () => {
    if (!user) return

    try {
      setIsLoading(true)
      const files = await listFiles(user.id)
      setFiles(files)
    } catch (error) {
      console.error("Error fetching files:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleFileClick = async (fileName: string) => {
    if (!user) return

    try {
      // Get the bucket name
      const bucketName = `user-${user.id}`

      // Get signed URL for the file
      const { data } = await supabase.storage.from(bucketName).createSignedUrl(fileName, 60 * 60 * 24) // 24 hours expiry

      if (data?.signedUrl) {
        setViewingFile(fileName)
        // Pass true as the third parameter to indicate this is an existing file
        onFileSelect(fileName, data.signedUrl, true)
      }
    } catch (error) {
      console.error("Error getting file URL:", error)
    }
  }

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split(".").pop()?.toLowerCase()
    switch (extension) {
      case "pdf":
        return "📄"
      case "docx":
        return "📝"
      case "pptx":
        return "📊"
      default:
        return "📎"
    }
  }

  function formatFileSize(bytes: number) {
    if (bytes === 0) return "0 Bytes"

    const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
    const i = Math.floor(Math.log(bytes) / Math.log(1024))

    return Number.parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + " " + sizes[i]
  }

  // If user is not signed in, show sign in message
  if (!user) {
    return (
      <div className="bg-white rounded-lg shadow-sm border p-4">
        <div className="flex flex-col items-center justify-center text-center py-4">
          <LogIn className="h-8 w-8 text-gray-400 mb-2" />
          <h3 className="text-sm font-medium mb-1">Sign in to view your uploaded files</h3>
          <p className="text-xs text-gray-500">Your files will be securely stored and accessible across sessions</p>
        </div>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-4">
        <Loader2 className="h-5 w-5 animate-spin text-primary mr-2" />
        <span>Loading files...</span>
      </div>
    )
  }

  if (files.length === 0) {
    return (
      <div className="text-center p-4 text-gray-500">
        <FileIcon className="h-5 w-5 mx-auto mb-2" />
        <p className="text-sm">No files uploaded yet</p>
      </div>
    )
  }

  // Calculate total size of all files
  const totalSize = files.reduce((total, file) => total + (file.metadata?.size || 0), 0)

  return (
    <div className="bg-white rounded-lg shadow-sm border p-3">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-medium">Your Files</h3>
        <span className="text-xs text-gray-500">Total: {formatFileSize(totalSize)}</span>
      </div>
      <ScrollArea className="h-[120px]">
        <div className="space-y-1">
          {files.map((file) => (
            <div key={file.name} className="flex items-center justify-between py-1 px-2 hover:bg-gray-50 rounded-md">
              <div className="flex items-center flex-1 min-w-0">
                <span className="mr-2">{getFileIcon(file.name)}</span>
                <span className="truncate max-w-[120px] text-sm">{file.name}</span>
                <span className="text-xs text-gray-500 ml-2 shrink-0">{formatFileSize(file.metadata?.size || 0)}</span>
              </div>
              <Button
                size="sm"
                variant={viewingFile === file.name ? "default" : "outline"}
                className={`ml-2 text-xs px-2 py-0 h-7 ${viewingFile === file.name ? "bg-green-500 hover:bg-green-600" : ""}`}
                onClick={() => handleFileClick(file.name)}
              >
                <Eye className="h-3 w-3 mr-1" />
                {viewingFile === file.name ? "Viewing" : "View"}
              </Button>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

