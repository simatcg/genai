import type { NextRequest } from "next/server"
import { spawn } from "child_process"
import path from "path"
import { promises as fs } from "fs"

// Route Segment Config
export const runtime = "nodejs"
export const dynamic = "force-dynamic"

// Helper function to create JSON responses
function createJsonResponse(data: any, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
    },
  })
}

// Test endpoint to verify the route is working
export async function GET(request: NextRequest) {
  console.log("[API] GET /api/process - Test endpoint")
  return createJsonResponse({ message: "API route is working" })
}

// Main API route handler
export async function POST(request: NextRequest) {
  console.log("==================================")
  console.log("[API] POST /api/process started")
  console.log("[API] Request received at:", new Date().toISOString())
  console.log("==================================")

  try {
    // Parse request body
    const body = await request.json()
    console.log("[API] Request body:", body)

    const { query, fileUrl } = body

    if (!query) {
      return createJsonResponse({ error: "Query is required" }, 400)
    }

    // Get the absolute path to the Python script
    const scriptPath = path.join(process.cwd(), "python", "process.py")
    console.log("[API] Script path:", scriptPath)

    // Check if Python script exists
    try {
      await fs.access(scriptPath, fs.constants.R_OK)
    } catch (error) {
      console.error("[API] Script not found:", error)
      return createJsonResponse(
        {
          error: "Script not found",
          details: error instanceof Error ? error.message : String(error),
        },
        500,
      )
    }

    // Execute Python script
    try {
      const result = await new Promise((resolve, reject) => {
        const pythonProcess = spawn("python", [scriptPath, query, fileUrl || ""])
        let stdout = ""
        let stderr = ""

        pythonProcess.stdout.on("data", (data) => {
          stdout += data.toString()
          console.log("[API] Python stdout:", data.toString())
        })

        pythonProcess.stderr.on("data", (data) => {
          stderr += data.toString()
          console.error("[API] Python stderr:", data.toString())
        })

        pythonProcess.on("error", (error) => {
          console.error("[API] Process error:", error)
          reject(error)
        })

        // Set a timeout
        const timeout = setTimeout(() => {
          pythonProcess.kill()
          reject(new Error("Process timed out after 50 seconds"))
        }, 50000)

        pythonProcess.on("close", (code) => {
          clearTimeout(timeout)
          console.log("[API] Process exited with code:", code)

          if (code !== 0) {
            reject(new Error(`Process failed with code ${code}: ${stderr}`))
            return
          }

          try {
            // Find the last valid JSON line
            const jsonLines = stdout
              .split("\n")
              .filter((line) => line.trim())
              .filter((line) => {
                try {
                  JSON.parse(line)
                  return true
                } catch {
                  return false
                }
              })

            if (jsonLines.length === 0) {
              reject(new Error("No valid JSON output found"))
              return
            }

            const lastJson = jsonLines[jsonLines.length - 1]
            resolve(JSON.parse(lastJson))
          } catch (error) {
            reject(new Error(`Failed to parse output: ${error}`))
          }
        })
      })

      return createJsonResponse({ result })
    } catch (error) {
      console.error("[API] Execution error:", error)
      return createJsonResponse(
        {
          error: "Execution failed",
          details: error instanceof Error ? error.message : String(error),
        },
        500,
      )
    }
  } catch (error) {
    console.error("[API] Uncaught error in API route:", error)
    return createJsonResponse(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : String(error),
      },
      500,
    )
  }
}

