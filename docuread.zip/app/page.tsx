"use client"

import type React from "react"

import { useState, useCallback, memo, useRef } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { uploadFile, listFiles } from "@/lib/storage"
import { Header } from "@/components/header"
import { DocumentViewer } from "@/components/document-viewer"
import { supabase } from "@/lib/supabase"
import { OverwriteDialog } from "@/components/overwrite-dialog"
import { FileSelector } from "@/components/file-selector"

// Define the structure for processed results
interface ProcessedResult {
  summary: string
  keyPoints: string[]
}

// Define chat message structure
interface ChatMessage {
  role: "user" | "assistant"
  content: string
  timestamp?: Date
}

// Create a memoized version of DocumentViewer to prevent unnecessary re-renders
const MemoizedDocumentViewer = memo(DocumentViewer)

export default function Page() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "uploading" | "success" | "error">("idle")
  const [uploadError, setUploadError] = useState<string>("")
  const [statusMessage, setStatusMessage] = useState<string>("")
  const [query, setQuery] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [processedResult, setProcessedResult] = useState<ProcessedResult | null>(null)
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([])
  const [fileUrl, setFileUrl] = useState<string>("")
  const [fileRefreshTrigger, setFileRefreshTrigger] = useState(0)
  const { user } = useAuth()
  const { toast } = useToast()
  const [showOverwriteDialog, setShowOverwriteDialog] = useState(false)
  const [pendingFile, setPendingFile] = useState<File | null>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  const checkForDuplicate = async (fileName: string): Promise<boolean> => {
    if (!user) return false

    try {
      const files = await listFiles(user.id)
      return files.some((file) => file.name.toLowerCase() === fileName.toLowerCase())
    } catch (error) {
      console.error("Error checking for duplicates:", error)
      return false
    }
  }

  const handleFileUpload = async (file: File, forceOverwrite = false) => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Authentication required",
        description: "Please sign in to upload files.",
      })
      return
    }

    // Validate file type
    const allowedTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ]
    const allowedExtensions = [".pdf", ".docx", ".pptx"]

    const fileExtension = `.${file.name.split(".").pop()?.toLowerCase()}`
    if (!allowedTypes.includes(file.type) && !allowedExtensions.includes(fileExtension)) {
      toast({
        variant: "destructive",
        title: "Invalid file type",
        description: "Please upload a PDF, Word (DOCX), or PowerPoint (PPTX) file.",
      })
      return
    }

    // Check for duplicates if not forcing overwrite
    if (!forceOverwrite) {
      const isDuplicate = await checkForDuplicate(file.name)
      if (isDuplicate) {
        setPendingFile(file)
        setShowOverwriteDialog(true)
        return
      }
    }

    setSelectedFile(file)
    setUploadStatus("uploading")
    setUploadError("")
    setStatusMessage("Uploading your document. Please wait...")

    try {
      const { url } = await uploadFile(user.id, file)
      setFileUrl(url)
      setUploadStatus("success")
      setStatusMessage("Document uploaded successfully! You can now ask questions about it.")
      setChatHistory([])
      // Trigger a refresh of the file list
      setFileRefreshTrigger((prev) => prev + 1)
      toast({
        title: "File uploaded successfully",
        description: "You can now start asking questions about your document.",
      })
    } catch (error: any) {
      console.error("Error in file upload process:", error)
      setUploadStatus("error")
      setUploadError(error.message || "Please try again later.")
      setStatusMessage(`Error uploading document: ${error.message || "Please try again later."}`)
      toast({
        variant: "destructive",
        title: "Error uploading file",
        description: error.message || "Please try again later.",
      })
    }
  }

  const handleOverwriteConfirm = () => {
    if (pendingFile) {
      handleFileUpload(pendingFile, true)
    }
    setShowOverwriteDialog(false)
    setPendingFile(null)
  }

  const handleOverwriteCancel = () => {
    setShowOverwriteDialog(false)
    setPendingFile(null)
    // Optionally show a toast that the upload was cancelled
    toast({
      title: "Upload cancelled",
      description: "The file upload was cancelled to prevent overwriting.",
    })
  }

  // Use a callback for file selection to prevent unnecessary re-renders
  const handleFileSelect = useCallback((fileName: string, url: string, isExistingFile = false) => {
    setSelectedFile(null)
    setFileUrl(url)
    setUploadStatus("success")

    // Set different message based on whether this is an existing file or a new upload
    if (isExistingFile) {
      setStatusMessage("Document previously uploaded and trained successfully. You can now ask questions about it.")
    } else {
      setStatusMessage("Document uploaded successfully! You can now ask questions about it.")
    }

    setChatHistory([])
  }, [])

  // Use a callback for query changes to prevent unnecessary re-renders
  const handleQueryChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setQuery(e.target.value)
  }, [])

  // Implement the Ask button handler
  const handleAskQuestion = async () => {
    if (!query.trim() || !fileUrl || isProcessing) return

    console.log("[Frontend] Processing question:", query)
    console.log("[Frontend] Sending request to API...")
    const startTime = Date.now()

    console.log("[Frontend] File URL:", fileUrl)

    setIsProcessing(true)

    // Add user question to chat history immediately
    const userMessage: ChatMessage = {
      role: "user",
      content: query,
      timestamp: new Date(),
    }

    setChatHistory((prev) => [...prev, userMessage])

    try {
      console.log("[Frontend] Sending request to /api/process")

      const response = await fetch("/api/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: query,
          fileUrl: fileUrl,
        }),
      })

      console.log(`[Frontend] Request sent, received response in ${Date.now() - startTime}ms`)
      console.log("[Frontend] Received response status:", response.status)

      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`)
      }

      const data = await response.json()
      console.log("[Frontend] Processed response data:", data)

      // Add assistant response to chat history
      const assistantMessage: ChatMessage = {
        role: "assistant",
        content: data.result.result || "Sorry, I couldn't process your question.",
        timestamp: new Date(),
      }

      setChatHistory((prev) => [...prev, assistantMessage])

      // Clear the query input
      setQuery("")

      // Scroll to the bottom of the chat
      setTimeout(() => {
        if (chatContainerRef.current) {
          chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight
        }
      }, 100)
    } catch (error) {
      console.error("[Frontend] Error processing query:", error)

      // Add error message to chat history
      const errorMessage: ChatMessage = {
        role: "assistant",
        content: "Sorry, there was an error processing your question. Please try again.",
        timestamp: new Date(),
      }

      setChatHistory((prev) => [...prev, errorMessage])

      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to process your question. Please try again.",
      })
    } finally {
      setIsProcessing(false)
      console.log("[Frontend] Query processing completed")
    }
  }

  const ensureUserBucket = async (userId: string): Promise<boolean> => {
    const bucketName = `user-${userId}`
    let retries = 3
    let delay = 1000

    while (retries > 0) {
      try {
        // Check if bucket exists
        const { data: buckets, error: listError } = await supabase.storage.listBuckets()

        if (listError) throw listError

        const bucketExists = buckets?.some((b) => b.name === bucketName)

        if (!bucketExists) {
          console.log("Creating bucket:", bucketName)
          const { data, error: createError } = await supabase.storage.createBucket(bucketName, {
            public: false,
            fileSizeLimit: 52428800,
            allowedMimeTypes: [
              "application/pdf",
              "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ],
          })

          if (createError) throw createError

          // Wait for bucket to be ready
          await new Promise((resolve) => setTimeout(resolve, 1000))
        }

        // Verify bucket is accessible
        const { error: verifyError } = await supabase.storage.from(bucketName).list()
        if (verifyError) throw verifyError

        return true
      } catch (error) {
        console.error(`Bucket creation attempt ${4 - retries} failed:`, error)
        retries--

        if (retries === 0) {
          throw new Error("Failed to ensure bucket exists")
        }

        await new Promise((resolve) => setTimeout(resolve, delay))
        delay *= 2
      }
    }

    return false
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200">
      <Header />

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left side: Document viewer with file selector above */}
          <div className="md:col-span-2 space-y-4">
            <FileSelector onFileSelect={handleFileSelect} refreshTrigger={fileRefreshTrigger} />

            <div className="bg-white rounded-lg shadow-lg overflow-hidden h-[600px]">
              <MemoizedDocumentViewer file={selectedFile} url={fileUrl} />
            </div>
          </div>

          {/* Right side: Upload box and chat interface */}
          <div className="space-y-6">
            {/* Upload box - now half width and on the right */}
            <div className="flex items-center justify-center w-full">
              <label
                htmlFor="dropzone-file"
                className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
              >
                <div className="flex flex-col items-center justify-center pt-3 pb-3">
                  <svg
                    className="w-6 h-6 mb-2 text-gray-500"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 20 16"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                    />
                  </svg>
                  <p className="mb-1 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-gray-500">PDF, DOCX, or PPTX (MAX. 50MB)</p>
                </div>
                <input
                  id="dropzone-file"
                  type="file"
                  className="hidden"
                  accept=".pdf,.docx,.pptx"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) handleFileUpload(file)
                  }}
                  disabled={uploadStatus === "uploading"}
                />
              </label>
            </div>

            {uploadStatus === "uploading" && (
              <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded relative" role="alert">
                <span className="block sm:inline">Uploading your document. Please wait...</span>
              </div>
            )}

            {uploadStatus === "error" && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span className="block sm:inline">Error uploading document: {uploadError}</span>
              </div>
            )}

            {uploadStatus === "success" && (
              <div
                className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative"
                role="alert"
              >
                <span className="block sm:inline">{statusMessage}</span>
              </div>
            )}

            {uploadStatus === "idle" && !selectedFile && !fileUrl && (
              <div className="bg-gray-50 border border-gray-200 text-gray-700 px-4 py-3 rounded relative" role="alert">
                <span className="block sm:inline">No document uploaded. Please upload a document to get started.</span>
              </div>
            )}

            <OverwriteDialog
              isOpen={showOverwriteDialog}
              onClose={handleOverwriteCancel}
              onConfirm={handleOverwriteConfirm}
              fileName={pendingFile?.name || ""}
            />

            {/* Chat interface */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-lg font-semibold mb-4">Ask Questions</h2>

              {/* Chat history display */}
              {chatHistory.length > 0 && (
                <div
                  ref={chatContainerRef}
                  className="mb-4 max-h-[300px] overflow-y-auto border rounded-md p-3 bg-gray-50 custom-scrollbar"
                >
                  {chatHistory.map((message, index) => (
                    <div
                      key={index}
                      className={`mb-3 ${
                        message.role === "user" ? "bg-blue-50 border-blue-100" : "bg-green-50 border-green-100"
                      } border rounded-lg p-3`}
                    >
                      <div className="flex items-center mb-1">
                        <span className="font-medium text-sm">{message.role === "user" ? "You" : "DocuRead AI"}</span>
                        {message.timestamp && (
                          <span className="text-xs text-gray-500 ml-2">{message.timestamp.toLocaleTimeString()}</span>
                        )}
                      </div>
                      <div className="text-sm whitespace-pre-wrap">{message.content}</div>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label htmlFor="query" className="block text-sm font-medium text-gray-700 mb-2">
                    Your Question
                  </label>
                  <textarea
                    id="query"
                    rows={4}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    placeholder="What would you like to know about this document?"
                    value={query}
                    onChange={handleQueryChange}
                    disabled={!fileUrl || isProcessing}
                    onKeyDown={(e) => {
                      // Submit on Ctrl+Enter or Cmd+Enter
                      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
                        handleAskQuestion()
                      }
                    }}
                  />
                </div>
                <button
                  type="button"
                  className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                    !fileUrl || !query || isProcessing
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  }`}
                  disabled={!fileUrl || !query || isProcessing}
                  onClick={handleAskQuestion}
                >
                  {isProcessing ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        />
                      </svg>
                      Processing...
                    </>
                  ) : (
                    "Ask"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

