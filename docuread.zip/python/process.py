import sys
import json
import os
import asyncio
from typing import Dict
 
from groundx import GroundX

def log(message: str):
    """Print a log message to stderr"""
    print(f"[Python] {message}", file=sys.stderr, flush=True)

def output_json(data: Dict):
    """Print JSON output to stdout"""
    print(json.dumps(data, ensure_ascii=False, separators=(',', ':')), flush=True)

async def process_query(query: str, file_url: str | None):
    """Async function to handle the query processing"""
    try:
        log("Importing required packages...")
        import groundx
        from groundx import GroundX
        import openai
        from openai import OpenAI, AsyncOpenAI
        log("Packages imported successfully")
    except ImportError as e:
        log(f"Import error: {str(e)}")
        return {
            "error": f"Failed to import required packages: {str(e)}"
        }

    try:
        # Initialize GroundX
        log("Initializing GroundX...")
        groundx_client = GroundX(
            api_key="bdf56986-8b0b-4a1b-8585-d25a8c19a348"
        )

        # Initialize OpenAI
        log("Initializing OpenAI...")
        openai.api_key = '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'
        os.environ["OPENAI_API_KEY"] = openai.api_key
        aclient = AsyncOpenAI()

        # Process with GroundX if file_url is provided
        groundx_score = None
        llm_text = ""
        if file_url and file_url.strip():
            log("Processing with GroundX...")
            try:
                content_response = groundx_client.search.content(
                    id=15969,
                    query=query
                )
                results = content_response.search
                llm_text = results.text
                groundx_score = results.score
                log(f"GroundX search completed with score: {groundx_score}")
            except Exception as e:
                log(f"GroundX processing error: {str(e)}")
                groundx_score = None

        # Get OpenAI completion
        log("Getting completion from OpenAI...")
        completion_model="gpt-4"  # Changed from gpt-4o to gpt-4
        instruction = """You are a highly knowledgeable assistant designed to demonstrate the effectiveness of the GroundX RAG (Retrieval-Augmented Generation) system. Your primary role is to assist developers by answering questions related to documents they have uploaded and that have been processed by the GroundX proprietary ingestion pipeline. This pipeline creates semantic objects and is known for delivering the highest accuracy in RAG retrievals on the market.
        Key Responsibilities:
        1. Document Verification and Summary:
        • When the developer asks about specific documents, your task is to verify that the documents have been successfully uploaded and processed. You may be asked to summarize the contents of a document, describe the types of data extracted, or confirm the presence of specific information.
        2. Handling Filenames:
        • Developers might refer to documents by filename. They may make minor spelling or case errors when mentioning filenames. Your task is to interpret these filenames as accurately as possible based on context and provide relevant responses, using the correct filenames from the processed content.
        3. Demonstrating RAG Capabilities:
        • Developers may test the accuracy and efficacy of the GroundX RAG ingestion by asking general or specific questions. Your answers should demonstrate the high accuracy and reliability of the retrievals, showcasing how well the system processes and retrieves information from their documents.
        • If asked to summarize, extract, or perform any other operation on the ingested documents, provide detailed and precise answers based on the semantic objects created during ingestion.
        Your Responses Should Be:
        1. Accurate and Detailed: Base your responses on the processed documents available in the system. Provide accurate and detailed information, ensuring that the developers see the full capabilities of the GroundX RAG system.
        2. Clear and Technical: Tailor your responses to a developer audience. Be precise in your explanations, using technical language where appropriate to demonstrate your understanding of the ingestion and retrieval process.
        3. Supportive of Testing: Understand that developers may be testing the system's capabilities. If a developer asks a general or test question, your response should help validate that the ingestion and retrieval processes have been successful.
        4. Context-Aware: Take into account any context provided by the developer, especially if they mention specific documents or filenames. Ensure that your answers are relevant to the specific queries asked.
        5. Informative about Errors: If a document cannot be found or if there is an issue with retrieval, inform the developer clearly and suggest checking the document upload process. Do not assume an error in the system unless explicitly noted.
        Handling Specific Scenarios:
        1. Document Not Found: If a document referenced by the developer is not found in the system, respond with a message that indicates this and suggest they verify the upload process.
        2. Incorrect or Ambiguous Filenames: If the developer refers to a document with a filename that is slightly incorrect or ambiguous, attempt to match it with the closest available document and confirm with the developer.
        3. General Questions: When asked general questions about the ingestion process, explain how GroundX's proprietary pipeline creates semantic objects from the uploaded documents and how this ensures the highest accuracy in RAG retrievals.
        """
    
        chat_completion = await aclient.chat.completions.create(
            model=completion_model,
            messages=[
                {
                    "role": "system",
                    "content": f"""{instruction}
                ===
                    {llm_text}
                ===
                    """
                },
                {"role": "user", "content": query},
            ],
        )

        # Prepare result
        result = {
            "query": query,
            "processed": True,
            "file_processed": bool(file_url and file_url.strip()),
            "file_url": file_url if file_url and file_url.strip() else None,
            "groundx_score": groundx_score,
            "result": chat_completion.choices[0].message.content
        }

        log("Processing completed successfully")
        return result

    except Exception as e:
        log(f"Processing error: {str(e)}")
        return {
            "error": f"Processing failed: {str(e)}",
            "query": query,
            "file_url": file_url
        }

def main():
    """Main entry point that runs the async function"""
    try:
        log("Starting script...")
        log(f"Arguments received: {sys.argv}")

        # Get arguments
        if len(sys.argv) < 2:
            output_json({"error": "No query provided"})
            sys.exit(1)

        query = sys.argv[1]
        file_url = sys.argv[2] if len(sys.argv) > 2 else None

        log(f"Processing query: {query}")
        log(f"File URL: {file_url}")

        # Run the async function and get result
        result = asyncio.run(process_query(query, file_url))
        
        # Output the result
        output_json(result)

    except Exception as e:
        log(f"Script error: {str(e)}")
        output_json({"error": str(e)})
        sys.exit(1)

if __name__ == "__main__":
    main()

